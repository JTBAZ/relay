import { RelayApp } from '@/components/relay/relay-app';

export default function Home() {
  return <RelayApp />;
}
