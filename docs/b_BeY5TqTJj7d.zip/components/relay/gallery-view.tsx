"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import {
  X,
  Heart,
  Share2,
  ChevronLeft,
  Crosshair,
  Eye,
  EyeOff,
  Tag,
  Star,
  Loader,
  MessageCircle,
} from "lucide-react";
import type { FeedPost, PositionalComment } from "@/lib/relay-fixtures";
import { CommentPin } from "./comment-pin";

interface GalleryViewProps {
  post: FeedPost;
  onClose: () => void;
  onNavigate?: (direction: "prev" | "next") => void;
  hasPrev?: boolean;
  hasNext?: boolean;
}

type ViewMode = "gallery" | "comment";

interface PendingComment {
  position: { x: number; y: number };
  text: string;
  tags: string[];
}

const TAG_SUGGESTIONS = [
  "landscape",
  "portrait",
  "abstract",
  "nature",
  "texture",
  "light study",
  "composition",
  "color",
];

export function GalleryView({
  post,
  onClose,
  onNavigate,
  hasPrev = false,
  hasNext = false,
}: GalleryViewProps) {
  const [liked, setLiked] = useState(false);
  const [viewMode, setViewMode] = useState<ViewMode>("gallery");
  const [comments, setComments] = useState<PositionalComment[]>(
    post.comments || []
  );
  const [pendingComment, setPendingComment] = useState<PendingComment | null>(
    null
  );
  const [commentText, setCommentText] = useState("");
  const [pendingTags, setPendingTags] = useState<string[]>([]);
  const [customTag, setCustomTag] = useState("");
  const [showPins, setShowPins] = useState(true);
  const [isFavorited, setIsFavorited] = useState(false);
  const imageRef = useRef<HTMLDivElement>(null);
  const commentInputRef = useRef<HTMLTextAreaElement>(null);

  // Handle ESC key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (viewMode === "comment") {
          setViewMode("gallery");
          setPendingComment(null);
          setCommentText("");
          setPendingTags([]);
          setCustomTag("");
        } else {
          onClose();
        }
      }
      if (viewMode === "gallery") {
        if (e.key === "ArrowLeft" && hasPrev && onNavigate) {
          onNavigate("prev");
        }
        if (e.key === "ArrowRight" && hasNext && onNavigate) {
          onNavigate("next");
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose, onNavigate, hasPrev, hasNext, viewMode]);

  // Focus comment input when placing pin
  useEffect(() => {
    if (pendingComment && commentInputRef.current) {
      commentInputRef.current.focus();
    }
  }, [pendingComment]);

  const handleImageClick = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (viewMode !== "comment") return;
      // Don't create new pin if we already have a pending one
      if (pendingComment) return;

      const rect = e.currentTarget.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;

      setPendingComment({ position: { x, y }, text: "", tags: [] });
    },
    [viewMode, pendingComment]
  );

  const handleCommentSubmit = () => {
    if (!pendingComment || !commentText.trim()) return;

    const newComment: PositionalComment = {
      id: `cm-${Date.now()}`,
      author: {
        id: "v1",
        displayName: "You",
        handle: "you",
        avatarUrl: "/placeholder.svg?height=32&width=32",
      },
      text: commentText.trim(),
      position: pendingComment.position,
      createdAt: "Just now",
      tags: pendingTags.length > 0 ? pendingTags : undefined,
    };

    setComments((prev) => [...prev, newComment]);
    setPendingComment(null);
    setCommentText("");
    setPendingTags([]);
    setCustomTag("");
    setViewMode("gallery");
  };

  const toggleTag = (tag: string) => {
    setPendingTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const addCustomTag = () => {
    const tag = customTag.trim().toLowerCase();
    if (tag && !pendingTags.includes(tag)) {
      setPendingTags((prev) => [...prev, tag]);
      setCustomTag("");
    }
  };

  const enterCommentMode = () => {
    setViewMode("comment");
  };

  const exitCommentMode = () => {
    setViewMode("gallery");
    setPendingComment(null);
    setCommentText("");
    setPendingTags([]);
    setCustomTag("");
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center animate-[fadeIn_0.2s_ease-out]"
      role="dialog"
      aria-modal="true"
      aria-label={`${post.title} by ${post.creator.displayName}`}
    >
      {/* Backdrop */}
      <div
        className={[
          "absolute inset-0 transition-colors duration-300",
          viewMode === "comment" ? "bg-black/98" : "bg-black/95",
        ].join(" ")}
        onClick={viewMode === "gallery" ? onClose : undefined}
      />

      {/* Close button */}
      <button
        onClick={viewMode !== "gallery" ? exitCommentMode : onClose}
        className="absolute top-4 right-4 z-50 w-10 h-10 rounded-full bg-[#1A1A1A] border border-[#2A2A2A] flex items-center justify-center text-[#888888] hover:text-white hover:border-[#3A3A3A] transition-colors"
        aria-label={viewMode !== "gallery" ? "Exit comment mode" : "Close gallery"}
      >
        <X size={18} />
      </button>

      {/* Navigation arrows */}
      {viewMode === "gallery" && onNavigate && (
        <>
          {hasPrev && (
            <button
              onClick={() => onNavigate("prev")}
              className="absolute left-4 top-1/2 -translate-y-1/2 z-50 w-10 h-10 rounded-full bg-[#1A1A1A]/80 border border-[#2A2A2A] flex items-center justify-center text-[#888888] hover:text-white hover:border-[#3A3A3A] transition-colors"
              aria-label="Previous post"
            >
              <ChevronLeft size={20} />
            </button>
          )}
        </>
      )}

      {/* Comment mode instruction banner */}
      {viewMode === "comment" && !pendingComment && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2.5 rounded-full bg-[#1B4332] border border-[#2D6A4F] text-[#40916C] text-sm font-medium shadow-lg">
          <Crosshair size={14} />
          Click anywhere on the image to leave a comment
        </div>
      )}

      {/* Main content */}
      <div
        className={[
          "relative z-10 w-full max-w-6xl max-h-[90vh] mx-4 flex flex-col transition-all duration-300 animate-[scaleIn_0.2s_ease-out]",
          viewMode === "comment" ? "max-w-5xl" : "",
        ].join(" ")}
      >
        {/* Image container */}
        <div
          ref={imageRef}
          onClick={handleImageClick}
          className={[
            "relative flex-1 min-h-0 flex items-center justify-center rounded-t-xl overflow-hidden group",
            viewMode === "comment"
              ? "cursor-crosshair bg-[#0A0A0A]"
              : "bg-[#0E0E0E]",
          ].join(" ")}
        >
          {/* Pin visibility toggle - always visible */}
          {viewMode === "gallery" && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowPins((prev) => !prev);
              }}
              className={[
                "absolute top-4 left-4 z-40 w-9 h-9 rounded-full flex items-center justify-center transition-all duration-200",
                showPins
                  ? "text-[#40916C] opacity-100 hover:text-[#55a87b]"
                  : "text-[#555555] opacity-50 hover:opacity-75 hover:text-[#666666]",
              ].join(" ")}
              aria-label={showPins ? "Hide comment pins" : "Show comment pins"}
              title={showPins ? "Hide pins" : "Show pins"}
            >
              {showPins ? <Eye size={14} /> : <EyeOff size={14} />}
            </button>
          )}
          {/* Main image */}
          <div className="relative max-h-[60vh] w-full flex items-center justify-center">
            <img
              src={post.highResImageUrl || post.coverImageUrl || "/placeholder.svg?height=800&width=1200"}
              alt={post.title}
              className="max-h-[60vh] max-w-full object-contain"
              crossOrigin="anonymous"
            />

            {/* Existing comment pins */}
            <div className="absolute inset-0">
              {showPins &&
                comments.map((comment, index) => (
                  <CommentPin key={comment.id} comment={comment} index={index} />
                ))}
            </div>

            {/* Pending comment pin */}
            {pendingComment && (
              <div
                className="absolute z-20"
                style={{
                  left: `${pendingComment.position.x}%`,
                  top: `${pendingComment.position.y}%`,
                  transform: "translate(-50%, -50%)",
                }}
              >
                <div className="w-8 h-8 rounded-full bg-[#2D6A4F] border-2 border-[#40916C] flex items-center justify-center text-white animate-pulse shadow-lg shadow-[#2D6A4F]/30">
                  <span className="text-xs font-semibold">
                    {comments.length + 1}
                  </span>
                </div>

                {/* Comment input popover */}
                <div
                  className="absolute top-full left-1/2 -translate-x-1/2 mt-3 w-72 bg-[#161616] border border-[#2A2A2A] rounded-lg p-2.5 shadow-2xl"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 rotate-45 bg-[#161616] border-l border-t border-[#2A2A2A]" />
                  
                  {/* Comment textarea */}
                  <textarea
                    ref={commentInputRef}
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder="Write your comment..."
                    className="w-full bg-[#1A1A1A] border border-[#242424] rounded px-2.5 py-2 text-sm text-[#E0E0E0] placeholder:text-[#444444] resize-none focus:outline-none focus:border-[#2D6A4F] transition-colors"
                    rows={2}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && e.metaKey) {
                        handleCommentSubmit();
                      }
                    }}
                  />

                  {/* Custom tag input */}
                  <div className="flex items-center gap-1.5 mt-2">
                    <Tag size={10} className="text-[#555555] shrink-0" />
                    <input
                      type="text"
                      value={customTag}
                      onChange={(e) => setCustomTag(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          addCustomTag();
                        }
                      }}
                      placeholder="Add tag..."
                      className="flex-1 bg-transparent border-none text-[11px] text-[#E0E0E0] placeholder:text-[#444444] focus:outline-none"
                    />
                  </div>

                  {/* Selected tags + Quick tag suggestions */}
                  <div className="flex flex-wrap gap-1 mt-2">
                    {pendingTags.map((tag) => (
                      <span
                        key={tag}
                        className="inline-flex items-center gap-0.5 text-[10px] px-1.5 py-0.5 rounded-full bg-[#1B4332] text-[#40916C] border border-[#2D6A4F]"
                      >
                        #{tag}
                        <button
                          onClick={() => toggleTag(tag)}
                          className="hover:text-white ml-0.5"
                        >
                          <X size={8} />
                        </button>
                      </span>
                    ))}
                    {TAG_SUGGESTIONS.slice(0, 4)
                      .filter((tag) => !pendingTags.includes(tag))
                      .map((tag) => (
                        <button
                          key={tag}
                          onClick={() => toggleTag(tag)}
                          className="text-[10px] px-1.5 py-0.5 rounded-full border border-[#2A2A2A] text-[#555555] hover:border-[#2D6A4F]/50 hover:text-[#40916C] transition-all"
                        >
                          {tag}
                        </button>
                      ))}
                  </div>

                  {/* Actions */}
                  <div className="flex justify-end items-center gap-2 mt-2.5 pt-2 border-t border-[#1F1F1F]">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setPendingComment(null);
                        setCommentText("");
                        setPendingTags([]);
                        setCustomTag("");
                      }}
                      className="px-2 py-1 text-[10px] text-[#555555] hover:text-[#888888] transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCommentSubmit();
                      }}
                      disabled={!commentText.trim()}
                      className="px-2.5 py-1 bg-[#2D6A4F] text-white rounded text-[10px] font-medium hover:bg-[#40916C] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      Pin
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Comment button with side actions */}
        {viewMode === "gallery" && (
          <div className="flex justify-center items-center gap-1 relative z-20">
            {/* Favorite button - left wing */}
            <button
              onClick={() => setIsFavorited(!isFavorited)}
              className={[
                "flex items-center justify-center w-8 h-8 rounded-lg transition-all",
                isFavorited
                  ? "text-[#40916C] border border-[#2D6A4F] bg-[#0D1F17]"
                  : "text-[#555555] border border-[#2A2A2A] bg-[#0E0E0E] hover:text-[#40916C] hover:border-[#2D6A4F]/50",
              ].join(" ")}
              aria-label={isFavorited ? "Remove from favorites" : "Add to favorites"}
              aria-pressed={isFavorited}
              title="Favorite"
            >
              <Star size={14} fill={isFavorited ? "currentColor" : "none"} />
            </button>

            {/* Pin a comment button - center */}
            <button
              onClick={enterCommentMode}
              className="group flex items-center gap-1.5 px-3 py-1.5 bg-[#0E0E0E] border border-[#2A2A2A] rounded-lg text-[#555555] text-xs hover:text-[#40916C] hover:border-[#2D6A4F]/50 transition-all"
              aria-label="Leave a pinned comment on this image"
            >
              <Crosshair size={12} className="group-hover:rotate-45 transition-transform" />
              Comment
              {comments.length > 0 && (
                <span className="opacity-60">({comments.length})</span>
              )}
            </button>

            {/* Snip button - right wing */}
            <button
              className={[
                "flex items-center justify-center w-8 h-8 rounded-lg transition-all",
                "text-[#555555] border border-[#2A2A2A] bg-[#0E0E0E] hover:text-[#40916C] hover:border-[#2D6A4F]/50",
              ].join(" ")}
              aria-label="Snip this image"
              title="Snip"
            >
              <Loader size={14} />
            </button>
          </div>
        )}

        {/* Info panel */}
        {viewMode === "gallery" && (
          <div className="bg-[#0E0E0E] border-t border-[#1A1A1A] rounded-b-xl p-5">
            {/* Artist info row */}
            <div className="flex items-start justify-between gap-4 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full overflow-hidden bg-[#2A2A2A] ring-2 ring-[#1A1A1A]">
                  <img
                    src={post.creator.avatarUrl}
                    alt=""
                    className="w-full h-full object-cover"
                    width={44}
                    height={44}
                  />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-[#F0F0F0]">
                      {post.creator.displayName}
                    </span>
                    <span className="text-xs text-[#555555]">
                      @{post.creator.handle}
                    </span>
                  </div>
                  <span className="text-xs text-[#444444]">
                    {post.creator.discipline}
                  </span>
                </div>
              </div>
            </div>

            {/* Title and description */}
            <h1 className="text-xl font-semibold text-[#F0F0F0] mb-2 text-balance">
              {post.title}
            </h1>
            <p className="text-sm text-[#5A5A5A] leading-relaxed mb-4">
              {post.description || post.excerpt}
            </p>

            {/* Community tags */}
            {post.communityTags && post.communityTags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mb-4 pb-4 border-b border-[#1A1A1A]">
                {post.communityTags.map((tag) => (
                  <span
                    key={tag}
                    className="text-xs px-2 py-0.5 rounded-full bg-[#0D1F17] text-[#40916C] border border-[#1B4332]/50 hover:border-[#2D6A4F] cursor-pointer transition-colors"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            )}

            {/* Action bar */}
            <div className="flex items-center gap-4">
              <button
                onClick={() => setLiked(!liked)}
                className={[
                  "flex items-center gap-1.5 text-sm transition-colors",
                  liked
                    ? "text-[#40916C]"
                    : "text-[#5A5A5A] hover:text-[#9CA3AF]",
                ].join(" ")}
                aria-label={liked ? "Unlike" : "Like"}
                aria-pressed={liked}
              >
                <Heart
                  size={16}
                  fill={liked ? "currentColor" : "none"}
                />
                {post.likeCount + (liked ? 1 : 0)}
              </button>

              <button
                className="flex items-center gap-1.5 text-sm text-[#5A5A5A] hover:text-[#9CA3AF] transition-colors"
                aria-label="Share"
              >
                <Share2 size={16} />
                Share
              </button>

              <span className="ml-auto text-xs text-[#444444]">
                {post.publishedAt}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
