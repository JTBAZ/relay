"use client";

import { AlertCircle, RefreshCw } from "lucide-react";
import { useState } from "react";

interface ErrorBannerProps {
  message?: string;
}

export function ErrorBanner({
  message = "We couldn't load the latest posts. Your last-viewed feed is shown.",
}: ErrorBannerProps) {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div
      className="flex items-start gap-3 px-4 py-3 rounded-lg bg-[#111111] border border-[#2A2A2A] text-sm"
      role="alert"
    >
      <AlertCircle
        size={15}
        className="text-[#6B7280] mt-0.5 shrink-0"
        aria-hidden="true"
      />
      <span className="text-[#9CA3AF] flex-1 leading-relaxed">{message}</span>
      <button
        onClick={() => setDismissed(false)}
        className="flex items-center gap-1.5 text-[#2D6A4F] hover:text-[#40916C] transition-colors duration-150 shrink-0 text-xs"
        aria-label="Retry loading feed"
      >
        <RefreshCw size={13} />
        Retry
      </button>
    </div>
  );
}
