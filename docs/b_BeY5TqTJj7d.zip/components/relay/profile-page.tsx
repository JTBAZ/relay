"use client";

import { useState } from "react";
import {
  ChevronRight,
  MapPin,
  Share2,
  Pencil,
  ImageIcon,
  Heart,
  MessageSquare,
  Bookmark,
  ArrowRight,
  Clock,
  ExternalLink,
} from "lucide-react";
import { CURRENT_VIEWER, FOLLOWED_CREATORS } from "@/lib/relay-fixtures";

// ── Placeholder data ──────────────────────────────────────────────────────────

const COLLECTIONS = [
  {
    id: "col1",
    title: "Fog & Silence",
    itemCount: 12,
    coverColor: "#141414",
  },
  {
    id: "col2",
    title: "Inspiration Board",
    itemCount: 8,
    coverColor: "#101a14",
  },
  {
    id: "col3",
    title: "Architecture",
    itemCount: 5,
    coverColor: "#141414",
  },
];

const RECENT_FAVORITES = [
  { id: "f1", label: "Golden Hour at the Cliffs" },
  { id: "f2", label: "Character Study #42" },
  { id: "f3", label: "Monsoon Fishermen" },
  { id: "f4", label: "Fog Composition" },
  { id: "f5", label: "Urban Negative Space" },
];

const SUPPORTED_CREATORS = [
  {
    id: FOLLOWED_CREATORS[0].id,
    handle: FOLLOWED_CREATORS[0].handle,
    displayName: FOLLOWED_CREATORS[0].displayName,
    discipline: FOLLOWED_CREATORS[0].discipline,
    avatarUrl: FOLLOWED_CREATORS[0].avatarUrl,
    tier: "Studio",
    tierColor: "#C5B358",
    status: "Active" as const,
    since: "Jan 2024",
  },
  {
    id: FOLLOWED_CREATORS[1].id,
    handle: FOLLOWED_CREATORS[1].handle,
    displayName: FOLLOWED_CREATORS[1].displayName,
    discipline: FOLLOWED_CREATORS[1].discipline,
    avatarUrl: FOLLOWED_CREATORS[1].avatarUrl,
    tier: "Supporter",
    tierColor: "#40916C",
    status: "Active" as const,
    since: "Mar 2024",
  },
  {
    id: FOLLOWED_CREATORS[2].id,
    handle: FOLLOWED_CREATORS[2].handle,
    displayName: FOLLOWED_CREATORS[2].displayName,
    discipline: FOLLOWED_CREATORS[2].discipline,
    avatarUrl: FOLLOWED_CREATORS[2].avatarUrl,
    tier: "Supporter",
    tierColor: "#40916C",
    status: "Active" as const,
    since: "Aug 2023",
  },
  {
    id: FOLLOWED_CREATORS[3].id,
    handle: FOLLOWED_CREATORS[3].handle,
    displayName: FOLLOWED_CREATORS[3].displayName,
    discipline: FOLLOWED_CREATORS[3].discipline,
    avatarUrl: FOLLOWED_CREATORS[3].avatarUrl,
    tier: "Supporter",
    tierColor: "#40916C",
    status: "Lapsed" as const,
    since: "Apr 2023",
  },
];

const RECENT_COMMENTS = [
  {
    id: "rc1",
    quote: "The way light hits the edge of that cliff is extraordinary — it almost reads as grief made visible.",
    postTitle: "Golden Hour at the Cliffs",
    creatorName: "Mara Osei",
    timestamp: "3 days ago",
    pinned: true,
  },
  {
    id: "rc2",
    quote: "This series keeps getting better. The restraint in the composition is doing a lot of heavy lifting.",
    postTitle: "Winter Light Series, Vol. 3",
    creatorName: "Elena Vasquez",
    timestamp: "1 week ago",
    pinned: false,
  },
  {
    id: "rc3",
    quote: "I didn't expect to feel something during a music piece about infrastructure — here we are.",
    postTitle: "Sound Waves Visualized",
    creatorName: "James Thorne",
    timestamp: "2 weeks ago",
    pinned: false,
  },
];

// ── Sub-components ─────────────────────────────────────────────────────────────

function SectionHeading({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="text-sm font-semibold text-[#C8C8C8] tracking-wide uppercase mb-4">
      {children}
    </h2>
  );
}

function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-[#0E0E0E] border border-[#1A1A1A] rounded-xl p-5 ${className}`}>
      {children}
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────

interface ProfilePageProps {
  onNavigate: (view: "home" | "discover") => void;
}

export function ProfilePage({ onNavigate }: ProfilePageProps) {
  const [collectionsEmpty] = useState(false);

  const activeCount = SUPPORTED_CREATORS.filter((c) => c.status === "Active").length;
  const lapsedCount = SUPPORTED_CREATORS.filter((c) => c.status === "Lapsed").length;

  return (
    <div className="min-h-full bg-[#0A0A0A] text-[#C8C8C8] font-sans">
      <div className="max-w-[960px] mx-auto px-4 sm:px-6 py-10 space-y-10">

        {/* ── 1. IDENTITY HEADER ── */}
        <section className="flex flex-col sm:flex-row sm:items-end gap-6">
          {/* Avatar */}
          <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden bg-[#1A1A1A] border border-[#242424] shrink-0">
            <img
              src={CURRENT_VIEWER.avatarUrl}
              alt={CURRENT_VIEWER.displayName}
              className="w-full h-full object-cover"
              width={96}
              height={96}
            />
          </div>
          {/* Identity text */}
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl sm:text-3xl font-semibold text-white tracking-tight text-balance">
              {CURRENT_VIEWER.displayName}
            </h1>
            <p className="text-sm text-[#555555] mt-0.5">@{CURRENT_VIEWER.handle}</p>
            <p className="text-sm text-[#888888] mt-2 leading-relaxed max-w-md">
              Collector of quiet images and slow ideas. Patron of work that resists the feed.
            </p>
          </div>
          {/* Actions */}
          <div className="flex items-center gap-2 shrink-0">
            <button className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#141414] border border-[#242424] text-sm text-[#C8C8C8] hover:border-[#333333] hover:text-white transition-colors duration-150">
              <Pencil size={13} aria-hidden="true" />
              Edit profile
            </button>
            <button className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-[#1A1A1A] text-sm text-[#555555] hover:border-[#2A2A2A] hover:text-[#888888] transition-colors duration-150">
              <Share2 size={13} aria-hidden="true" />
              Share
            </button>
          </div>
        </section>

        {/* ── 2. TASTE ── */}
        <section>
          <SectionHeading>Collections</SectionHeading>

          {collectionsEmpty ? (
            <Card>
              <div className="text-center py-8">
                <Bookmark size={28} className="mx-auto mb-3 text-[#2A2A2A]" aria-hidden="true" />
                <p className="text-sm text-[#555555] mb-1">No collections yet</p>
                <p className="text-xs text-[#3A3A3A] mb-5">
                  Save work you love and build collections around ideas that matter to you.
                </p>
                <div className="flex items-center justify-center gap-3">
                  <button className="px-4 py-2 rounded-lg bg-[#2D6A4F] text-sm text-white font-medium hover:bg-[#40916C] transition-colors duration-150">
                    Save your first favorite
                  </button>
                  <button className="px-4 py-2 rounded-lg border border-[#242424] text-sm text-[#555555] hover:text-[#888888] hover:border-[#333333] transition-colors duration-150">
                    Create a collection
                  </button>
                </div>
              </div>
            </Card>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {COLLECTIONS.map((col) => (
                <button
                  key={col.id}
                  className="group text-left bg-[#0E0E0E] border border-[#1A1A1A] rounded-xl overflow-hidden hover:border-[#2A2A2A] transition-colors duration-150"
                >
                  {/* Thumbnail area */}
                  <div
                    className="h-28 flex items-center justify-center"
                    style={{ background: col.coverColor }}
                    aria-hidden="true"
                  >
                    <ImageIcon size={22} className="text-[#2A2A2A] group-hover:text-[#3A3A3A] transition-colors duration-150" />
                  </div>
                  <div className="px-4 py-3 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-[#C8C8C8] group-hover:text-white transition-colors duration-150">
                        {col.title}
                      </p>
                      <p className="text-xs text-[#3A3A3A] mt-0.5">{col.itemCount} items</p>
                    </div>
                    <ChevronRight size={14} className="text-[#3A3A3A] group-hover:text-[#555555] transition-colors duration-150" />
                  </div>
                </button>
              ))}
            </div>
          )}

          {/* Recent Favorites */}
          {!collectionsEmpty && (
            <div className="mt-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs font-semibold uppercase tracking-widest text-[#3A3A3A]">
                  Recent favorites
                </h3>
                <button className="text-xs text-[#40916C] hover:text-[#52a87d] transition-colors duration-150">
                  View all
                </button>
              </div>
              <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
                {RECENT_FAVORITES.map((fav) => (
                  <button
                    key={fav.id}
                    className="group shrink-0 flex flex-col gap-1.5"
                    title={fav.label}
                  >
                    <div className="w-16 h-16 rounded-lg bg-[#141414] border border-[#1A1A1A] group-hover:border-[#2A2A2A] flex items-center justify-center transition-colors duration-150">
                      <Heart size={14} className="text-[#2A2A2A] group-hover:text-[#3A3A3A] transition-colors duration-150" aria-hidden="true" />
                    </div>
                    <p className="text-[10px] text-[#444444] w-16 truncate text-center leading-tight">
                      {fav.label}
                    </p>
                  </button>
                ))}
              </div>
            </div>
          )}
        </section>

        {/* ── 3. SUPPORT NETWORK ── */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <SectionHeading>Creators you support</SectionHeading>
            <span className="text-xs text-[#444444] -mt-4">
              {activeCount} active · {lapsedCount} lapsed
            </span>
          </div>

          <div className="space-y-2">
            {SUPPORTED_CREATORS.map((creator) => (
              <button
                key={creator.id}
                className="w-full flex items-center gap-4 bg-[#0E0E0E] border border-[#1A1A1A] rounded-xl px-4 py-3.5 hover:border-[#2A2A2A] transition-colors duration-150 group"
              >
                {/* Avatar */}
                <div className="w-9 h-9 rounded-full overflow-hidden bg-[#1A1A1A] border border-[#222222] shrink-0">
                  <img
                    src={creator.avatarUrl}
                    alt=""
                    className="w-full h-full object-cover"
                    width={36}
                    height={36}
                  />
                </div>
                {/* Info */}
                <div className="flex-1 text-left min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-medium text-[#C8C8C8] group-hover:text-white transition-colors duration-150 truncate">
                      {creator.displayName}
                    </span>
                    <span
                      className="text-[10px] font-semibold px-2 py-0.5 rounded-full border shrink-0"
                      style={{
                        color: creator.tierColor,
                        borderColor: `${creator.tierColor}33`,
                        backgroundColor: `${creator.tierColor}11`,
                      }}
                    >
                      {creator.tier}
                    </span>
                    <span
                      className={[
                        "text-[10px] px-2 py-0.5 rounded-full border shrink-0",
                        creator.status === "Active"
                          ? "text-[#40916C] border-[#40916C]/20 bg-[#40916C]/10"
                          : "text-[#555555] border-[#333333] bg-[#141414]",
                      ].join(" ")}
                    >
                      {creator.status}
                    </span>
                  </div>
                  <p className="text-xs text-[#444444] mt-0.5 truncate">
                    {creator.discipline} · since {creator.since}
                  </p>
                </div>
                <ChevronRight
                  size={14}
                  className="text-[#2A2A2A] group-hover:text-[#444444] shrink-0 transition-colors duration-150"
                  aria-hidden="true"
                />
              </button>
            ))}
          </div>

          <button className="mt-3 text-xs text-[#3A3A3A] hover:text-[#555555] transition-colors duration-150">
            Former subscriptions
          </button>
        </section>

        {/* ── 4. VOICE ON WORK ── */}
        <section>
          <SectionHeading>Recent on posts</SectionHeading>

          <div className="space-y-2">
            {RECENT_COMMENTS.map((comment) => (
              <Card key={comment.id} className="group">
                <div className="flex items-start gap-3">
                  <MessageSquare
                    size={13}
                    className={[
                      "mt-0.5 shrink-0",
                      comment.pinned ? "text-[#C5B358]" : "text-[#333333]",
                    ].join(" ")}
                    aria-hidden="true"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-[#A0A0A0] leading-relaxed italic">
                      &ldquo;{comment.quote}&rdquo;
                    </p>
                    <div className="flex items-center justify-between gap-3 mt-2 flex-wrap">
                      <p className="text-xs text-[#444444] truncate">
                        on{" "}
                        <span className="text-[#555555]">{comment.postTitle}</span>
                        {" "}by {comment.creatorName}
                      </p>
                      <div className="flex items-center gap-3 shrink-0">
                        <span className="flex items-center gap-1 text-xs text-[#3A3A3A]">
                          <Clock size={10} aria-hidden="true" />
                          {comment.timestamp}
                        </span>
                        <button className="text-xs text-[#40916C] hover:text-[#52a87d] transition-colors duration-150 flex items-center gap-1">
                          Open
                          <ExternalLink size={10} aria-hidden="true" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* ── 5. WHAT'S NEXT ── */}
        <section>
          <Card>
            <div className="flex items-start justify-between gap-4 flex-wrap">
              <div>
                <h2 className="text-sm font-semibold text-[#C8C8C8] tracking-wide uppercase mb-2">
                  Commission Hub
                </h2>
                <p className="text-sm text-[#555555] leading-relaxed">
                  You have 1 bookmarked brief and 1 draft inquiry.
                </p>
                <button className="mt-2 text-xs text-[#C5B358] hover:text-[#d4c370] transition-colors duration-150">
                  Browse marketplace
                </button>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => onNavigate("home")}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#141414] border border-[#242424] text-xs text-[#888888] hover:text-[#C8C8C8] hover:border-[#333333] transition-colors duration-150"
                >
                  Go to feed
                  <ArrowRight size={11} aria-hidden="true" />
                </button>
                <button
                  onClick={() => onNavigate("discover")}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#141414] border border-[#242424] text-xs text-[#888888] hover:text-[#C8C8C8] hover:border-[#333333] transition-colors duration-150"
                >
                  Discover
                  <ArrowRight size={11} aria-hidden="true" />
                </button>
              </div>
            </div>
          </Card>
        </section>

        {/* ── 6. FOOTER STRIP ── */}
        <footer className="border-t border-[#141414] pt-6 pb-4">
          <nav className="flex items-center gap-6 flex-wrap" aria-label="Account">
            {["Notifications", "Preferences", "Settings"].map((label) => (
              <button
                key={label}
                className="text-xs text-[#3A3A3A] hover:text-[#666666] transition-colors duration-150"
              >
                {label}
              </button>
            ))}
          </nav>
        </footer>

      </div>
    </div>
  );
}
