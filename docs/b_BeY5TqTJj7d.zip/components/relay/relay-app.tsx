"use client";

import { useState, useMemo, useCallback, useEffect } from "react";
import {
  Home,
  Compass,
  BookOpen,
  Settings,
  Bell,
  Menu,
  X,
  Search,
  Command,
  User,
} from "lucide-react";
import { DiscoverGrid } from "./discover-grid";
import { FeedCard } from "./feed-card";
import { FeedSectionDivider } from "./feed-section-divider";
import { EmptyState } from "./empty-state";
import { ErrorBanner } from "./error-banner";
import { CommandPalette } from "./command-palette";
import { GalleryView } from "./gallery-view";
import { SettingsModal } from "./settings-modal";
import { NotificationsTray } from "./notifications-tray";
import { LibraryModal } from "./library-modal";
import { ProfilePage } from "./profile-page";
import { FilterChips, type FeedFilter } from "./filter-chips";
import {
  FEED_POSTS,
  DISCOVER_ITEMS,
  CURRENT_VIEWER,
  FOLLOWED_CREATORS,
  NOTIFICATIONS,
  LIBRARY_IMAGES,
  type FeedPost,
  type DiscoverItem,
  type LibraryImage,
} from "@/lib/relay-fixtures";

type AppView = "home" | "discover" | "profile";

const DEMO_EMPTY_FOLLOWS = false;
const DEMO_ERROR_BANNER = false;
const TRANSITION_DURATION = 400;

const NAV_ITEMS = [
  { id: "home", label: "Home", icon: Home },
  { id: "discover", label: "Discover", icon: Compass },
  { id: "library", label: "Library", icon: BookOpen },
  { id: "profile", label: "My Profile", icon: User },
] as const;

function filterPosts(posts: FeedPost[], filter: FeedFilter): FeedPost[] {
  switch (filter) {
    case "following":
      return posts.filter((p) => p.kind === "followed");
    case "free":
      return posts.filter((p) => p.tierLabel === "Free" || p.kind === "discovery");
    case "photos":
      return posts.filter((p) => p.mediaType === "photo");
    case "audio":
      return posts.filter((p) => p.mediaType === "audio");
    case "writing":
      return posts.filter((p) => p.mediaType === "writing");
    default:
      return posts;
  }
}

function discoverItemToPost(item: DiscoverItem): FeedPost {
  return {
    id: item.id,
    kind: "discovery",
    creator: item.creator,
    title: item.title,
    excerpt: `A ${item.mediaType} by ${item.creator.displayName}`,
    mediaType: item.mediaType,
    coverImageUrl: item.imageUrl,
    highResImageUrl: item.imageUrl.replace("height=", "height=800&width=1200&orig_height="),
    publishedAt: "Recent",
    likeCount: item.likeCount,
    commentCount: item.commentCount,
    tierLabel: "Free",
  };
}

export function RelayApp() {
  const [currentView, setCurrentView] = useState<AppView>("home");
  const [transitionState, setTransitionState] = useState<TransitionState>("idle");
  const [activeFilter, setActiveFilter] = useState<FeedFilter>("all");
  const [commandOpen, setCommandOpen] = useState(false);
  const [selectedPost, setSelectedPost] = useState<FeedPost | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [libraryOpen, setLibraryOpen] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const openCommand = () => setCommandOpen(true);

  // Smooth view transition with sidebar slide
  const navigateTo = useCallback((targetView: AppView) => {
    if (targetView === currentView || transitionState !== "idle") return;
    
    setTransitionState("exiting");
    
    setTimeout(() => {
      setCurrentView(targetView);
      setTransitionState("entering");
      
      setTimeout(() => {
        setTransitionState("idle");
      }, TRANSITION_DURATION);
    }, TRANSITION_DURATION);
  }, [currentView, transitionState]);

  // Command+K shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        openCommand();
      }
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, []);

  // Close mobile sidebar on wide viewports
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 1024px)");
    const handler = (e: MediaQueryListEvent) => {
      if (e.matches) setMobileSidebarOpen(false);
    };
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);

  const filteredPosts = useMemo(
    () => filterPosts(FEED_POSTS, activeFilter),
    [activeFilter]
  );

  const enrichedPosts = useMemo(() => {
    let dividerInserted = false;
    return filteredPosts.map((post) => {
      const showDivider = post.kind === "discovery" && !dividerInserted;
      if (showDivider) dividerInserted = true;
      return { post, showDivider };
    });
  }, [filteredPosts]);

  const selectedPostIndex = selectedPost
    ? filteredPosts.findIndex((p) => p.id === selectedPost.id)
    : -1;

  const handleNavigate = useCallback(
    (direction: "prev" | "next") => {
      if (selectedPostIndex === -1) return;
      const newIndex =
        direction === "prev" ? selectedPostIndex - 1 : selectedPostIndex + 1;
      if (newIndex >= 0 && newIndex < filteredPosts.length) {
        setSelectedPost(filteredPosts[newIndex]);
      }
    },
    [selectedPostIndex, filteredPosts]
  );

  const handleDiscoverItemClick = (item: DiscoverItem) => {
    const post = discoverItemToPost(item);
    setSelectedPost(post);
  };

  const handleMatchVibe = (image: LibraryImage) => {
    // Filter discover items by matching vibe
    const vibeMatches = DISCOVER_ITEMS.filter((item) => {
      // Simple vibe matching based on aesthetic attributes
      const itemVibe = item.aspectRatio === "square" ? "minimal" : 
                      item.aspectRatio === "portrait" ? "serene" : "vibrant";
      return itemVibe === image.vibe;
    });

    if (vibeMatches.length > 0) {
      navigateTo("discover");
      // Could add scroll to first match or filter the discover feed
    }
  };

  const isDiscover = currentView === "discover" || currentView === "profile";

  return (
    <>
      <CommandPalette open={commandOpen} onClose={() => setCommandOpen(false)} />

      {selectedPost && (
        <GalleryView
          post={selectedPost}
          onClose={() => setSelectedPost(null)}
          onNavigate={handleNavigate}
          hasPrev={selectedPostIndex > 0}
          hasNext={selectedPostIndex < filteredPosts.length - 1}
        />
      )}

      <div className="flex h-screen overflow-hidden bg-[#0A0A0A]">
        {/* Mobile overlay */}
        {mobileSidebarOpen && (
          <div
            className="fixed inset-0 z-30 bg-black/70 lg:hidden"
            onClick={() => setMobileSidebarOpen(false)}
            aria-hidden="true"
          />
        )}

        {/* Persistent Sidebar - animates width, condenses to icons */}
        <aside
          style={{
            transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)",
          }}
          className={[
            "fixed lg:static top-0 left-0 z-40 h-full bg-[#0E0E0E] border-r border-[#1A1A1A] flex flex-col overflow-hidden",
            // Mobile: slide in/out
            mobileSidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
            // Desktop: animate width based on view (240px -> 72px)
            isDiscover ? "lg:w-[72px]" : "lg:w-60",
            "w-60",
          ].join(" ")}
          aria-label="Main navigation"
        >
          <div 
            style={{
              transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)",
            }}
            className={[
              "flex flex-col h-full",
              isDiscover ? "lg:w-[72px]" : "w-60",
            ].join(" ")}
          >
            {/* Wordmark */}
            <div 
              style={{ transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)" }}
              className={[
                "flex items-center h-[56px] border-b border-[#1A1A1A] shrink-0",
                isDiscover ? "lg:justify-center lg:px-0 px-5" : "justify-between px-5",
              ].join(" ")}
            >
              <span
                style={{ 
                  color: "#C5B358",
                  transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)",
                }}
                className={[
                  "font-bold tracking-tight select-none",
                  isDiscover ? "lg:text-[16px] text-[20px]" : "text-[20px]",
                ].join(" ")}
                aria-label="Relay"
              >
                {isDiscover ? <span className="lg:hidden">Relay</span> : "Relay"}
                <span 
                  style={{ transition: "opacity 400ms cubic-bezier(0.25, 0.1, 0.25, 1)" }}
                  className={[
                    "hidden",
                    isDiscover ? "lg:inline" : "",
                  ].join(" ")}
                >
                  R
                </span>
              </span>
              <button
                onClick={() => setMobileSidebarOpen(false)}
                className={[
                  "lg:hidden p-1 text-[#4B5563] hover:text-[#9CA3AF] transition-colors duration-150",
                ].join(" ")}
                aria-label="Close navigation"
              >
                <X size={17} />
              </button>
            </div>

            {/* Primary nav */}
            <nav 
              style={{ transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)" }}
              className={[
                "pt-4 space-y-0.5",
                isDiscover ? "lg:px-2 px-3" : "px-3",
              ].join(" ")}
            >
              {NAV_ITEMS.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    if (item.id === "home") navigateTo("home");
                    if (item.id === "discover") navigateTo("discover");
                    if (item.id === "profile") navigateTo("profile");
                    if (item.id === "library") setLibraryOpen(true);
                  }}
                  style={{ transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)" }}
                  className={[
                    "w-full flex items-center rounded-lg text-sm font-medium",
                    isDiscover ? "lg:justify-center lg:px-0 lg:py-3 gap-3 px-3 py-2.5" : "gap-3 px-3 py-2.5",
                    item.id === currentView
                      ? "bg-[#0D1F17] text-[#40916C] border border-[#1B4332]/40"
                      : "text-[#5A5A5A] hover:bg-[#141414] hover:text-[#9CA3AF]",
                  ].join(" ")}
                  aria-current={
                    (item.id === currentView) ? "page" : undefined
                  }
                  title={isDiscover ? item.label : undefined}
                >
                  <item.icon size={isDiscover ? 18 : 15} aria-hidden="true" className="shrink-0" />
                  <span 
                    style={{ transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)" }}
                    className={[
                      "whitespace-nowrap overflow-hidden",
                      isDiscover ? "lg:w-0 lg:opacity-0" : "w-auto opacity-100",
                    ].join(" ")}
                  >
                    {item.label}
                  </span>
                </button>
              ))}
            </nav>

            {/* Divider */}
            <div 
              style={{ transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)" }}
              className={[
                "mt-4 mb-4 border-t border-[#1A1A1A]",
                isDiscover ? "lg:mx-2 mx-5" : "mx-5",
              ].join(" ")} 
            />

            {/* Following list - hidden in icon mode */}
            <div 
              style={{ transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)" }}
              className={[
                "flex-1 overflow-y-auto min-h-0",
                isDiscover ? "lg:hidden px-3" : "px-3",
              ].join(" ")}
            >
              <div className="flex items-center justify-between px-3 mb-2">
                <span className="text-[10px] uppercase tracking-widest font-semibold text-[#3A3A3A]">
                  Following
                </span>
                <span className="text-[10px] text-[#3A3A3A]">
                  {FOLLOWED_CREATORS.length}
                </span>
              </div>
              <ul className="space-y-0.5">
                {FOLLOWED_CREATORS.map((creator) => (
                  <li key={creator.id}>
                    <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs text-[#5A5A5A] hover:bg-[#141414] hover:text-[#9CA3AF] transition-colors duration-150">
                      <div
                        className="w-6 h-6 rounded-full overflow-hidden bg-[#2A2A2A] shrink-0"
                        aria-hidden="true"
                      >
                        <img
                          src={creator.avatarUrl}
                          alt=""
                          className="w-full h-full object-cover"
                          width={24}
                          height={24}
                        />
                      </div>
                      <span className="truncate flex-1 text-left">
                        {creator.displayName}
                      </span>
                      <span
                        className="w-1.5 h-1.5 rounded-full bg-[#2D6A4F] shrink-0"
                        aria-label="New content"
                      />
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Divider */}
            <div 
              style={{ transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)" }}
              className={[
                "mt-3 mb-3 border-t border-[#1A1A1A]",
                isDiscover ? "lg:mx-2 mx-5" : "mx-5",
              ].join(" ")} 
            />

            {/* Footer: settings + viewer */}
            <div 
              style={{ transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)" }}
              className={[
                "pb-4 space-y-0.5 shrink-0",
                isDiscover ? "lg:px-2 px-3" : "px-3",
              ].join(" ")}
            >
              <button 
                style={{ transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)" }}
                className={[
                  "w-full flex items-center rounded-lg text-sm text-[#5A5A5A] hover:bg-[#141414] hover:text-[#9CA3AF]",
                  isDiscover ? "lg:justify-center lg:px-0 lg:py-3 gap-3 px-3 py-2.5" : "gap-3 px-3 py-2.5",
                ].join(" ")}
                title={isDiscover ? "Settings" : undefined}
              >
                <Settings size={isDiscover ? 18 : 14} aria-hidden="true" className="shrink-0" />
                <span 
                  style={{ transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)" }}
                  className={[
                    "whitespace-nowrap overflow-hidden",
                    isDiscover ? "lg:w-0 lg:opacity-0" : "w-auto opacity-100",
                  ].join(" ")}
                >
                  Settings
                </span>
              </button>
              <button 
                onClick={() => navigateTo("profile")}
                style={{ transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)" }}
                className={[
                  "w-full flex items-center rounded-lg hover:bg-[#141414]",
                  isDiscover ? "lg:justify-center lg:px-0 lg:py-2 gap-3 px-3 py-2.5" : "gap-3 px-3 py-2.5",
                ].join(" ")}
              >
                <div
                  className="w-7 h-7 rounded-full overflow-hidden bg-[#2A2A2A] shrink-0"
                  aria-hidden="true"
                >
                  <img
                    src={CURRENT_VIEWER.avatarUrl}
                    alt=""
                    className="w-full h-full object-cover"
                    width={28}
                    height={28}
                  />
                </div>
                <div 
                  style={{ transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)" }}
                  className={[
                    "flex-1 text-left overflow-hidden",
                    isDiscover ? "lg:hidden" : "",
                  ].join(" ")}
                >
                  <div className="text-xs text-[#C8C8C8] truncate font-medium">
                    {CURRENT_VIEWER.displayName}
                  </div>
                  <div className="text-[10px] text-[#444444] truncate">
                    @{CURRENT_VIEWER.handle}
                  </div>
                </div>
              </button>
            </div>
          </div>
        </aside>

        {/* Main content area */}
        <div className="flex flex-col flex-1 overflow-hidden min-w-0">
          {/* Top bar */}
          <header className={[
            "flex items-center gap-3 px-4 lg:px-5 h-[56px] border-b border-[#1A1A1A] shrink-0",
            isDiscover ? "bg-[#0A0A0A]/80 backdrop-blur-sm" : "bg-[#0A0A0A]",
          ].join(" ")}>
            {/* Hamburger - mobile */}
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="lg:hidden p-1.5 text-[#4B5563] hover:text-[#9CA3AF] transition-colors duration-150 shrink-0"
              aria-label="Open navigation"
              aria-expanded={mobileSidebarOpen}
            >
              <Menu size={19} />
            </button>

            {/* Wordmark - mobile only since sidebar stays visible */}
            <span
              className="lg:hidden font-bold tracking-tight text-[18px] shrink-0 select-none"
              style={{ color: "#C5B358" }}
              aria-hidden="true"
            >
              Relay
            </span>

            {/* Search trigger */}
            <div className="flex-1 flex justify-center">
              <button
                onClick={openCommand}
                className={[
                  "flex items-center gap-2.5 px-3.5 py-2 bg-[#111111] border border-[#222222] rounded-lg text-sm text-[#444444] hover:border-[#2E2E2E] hover:text-[#666666] transition-colors duration-150 group",
                  isDiscover ? "w-auto" : "w-full max-w-[480px]",
                ].join(" ")}
                aria-label="Open search (Command K)"
              >
                <Search size={13} aria-hidden="true" />
                <span className={[
                  "text-left text-sm",
                  isDiscover ? "hidden sm:inline" : "flex-1",
                ].join(" ")}>
                  {isDiscover ? "Search" : "Search creators and posts…"}
                </span>
                <span className="hidden sm:flex items-center gap-0.5 px-1.5 py-0.5 rounded border border-[#222222] text-[10px] font-mono text-[#333333] group-hover:border-[#2E2E2E] transition-colors duration-150">
                  <Command size={8} aria-hidden="true" />K
                </span>
              </button>
            </div>

            {/* Right controls */}
            <div className="flex items-center gap-1 shrink-0 relative">
              <button
                onClick={() => setLibraryOpen(!libraryOpen)}
                className="p-2 text-[#4B5563] hover:text-[#9CA3AF] transition-colors duration-150 rounded-lg hover:bg-[#111111]"
                aria-label="Open Library"
                title="Library"
              >
                <BookOpen size={17} aria-hidden="true" />
              </button>

              <button
                onClick={() => setNotificationsOpen(!notificationsOpen)}
                className="relative p-2 text-[#4B5563] hover:text-[#9CA3AF] transition-colors duration-150 rounded-lg hover:bg-[#111111]"
                aria-label={`Notifications (${NOTIFICATIONS.filter(n => !n.read).length} unread)`}
                title="Notifications"
              >
                <Bell size={17} aria-hidden="true" />
                {NOTIFICATIONS.filter(n => !n.read).length > 0 && (
                  <span
                    className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full bg-[#2D6A4F]"
                    aria-hidden="true"
                  />
                )}
              </button>

              <button
                onClick={() => setSettingsOpen(!settingsOpen)}
                className="p-2 text-[#4B5563] hover:text-[#9CA3AF] transition-colors duration-150 rounded-lg hover:bg-[#111111]"
                aria-label="Settings"
                title="Settings"
              >
                <Settings size={17} aria-hidden="true" />
              </button>
              
              <div
                className="w-8 h-8 rounded-full overflow-hidden bg-[#2A2A2A] border border-[#222222] shrink-0"
                aria-hidden="true"
              >
                <img
                  src={CURRENT_VIEWER.avatarUrl}
                  alt=""
                  className="w-full h-full object-cover"
                  width={32}
                  height={32}
                />
              </div>
            </div>
          </header>

          {/* Notifications Tray */}
          {notificationsOpen && (
            <div className="absolute top-[56px] right-4 z-30">
              <NotificationsTray
                notifications={NOTIFICATIONS}
                isOpen={notificationsOpen}
              />
            </div>
          )}

          {/* Filter subnav - only for Home */}
          {!isDiscover && (
            <div className="flex items-center justify-between gap-4 px-4 lg:px-5 py-3 border-b border-[#151515] bg-[#0A0A0A] shrink-0">
              <FilterChips value={activeFilter} onChange={setActiveFilter} />
              <div className="hidden sm:flex items-center gap-1.5 shrink-0">
                <span
                  className="w-1.5 h-1.5 rounded-full bg-[#2D6A4F]"
                  aria-hidden="true"
                />
                <span className="text-[11px] text-[#3A3A3A] font-medium whitespace-nowrap">
                  Chronological
                </span>
              </div>
            </div>
          )}

          {/* Scrollable content */}
          <main className="flex-1 overflow-y-auto" id="feed-main">
            <div
              style={{ transition: "all 400ms cubic-bezier(0.25, 0.1, 0.25, 1)" }}
              className={[
                transitionState === "idle"
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-4",
              ].join(" ")}
            >
              {currentView === "home" ? (
                <div className="max-w-[880px] mx-auto px-4 lg:px-6 py-6">
                  <div className="space-y-3">
                    {DEMO_ERROR_BANNER && <ErrorBanner />}

                    {DEMO_EMPTY_FOLLOWS ? (
                      <EmptyState onSearch={openCommand} />
                    ) : filteredPosts.length === 0 ? (
                      <div className="flex flex-col items-center py-20 text-center">
                        <p className="text-sm text-[#5A5A5A]">
                          No posts match this filter.
                        </p>
                        <button
                          onClick={() => setActiveFilter("all")}
                          className="mt-4 text-sm text-[#2D6A4F] hover:text-[#40916C] transition-colors duration-150"
                        >
                          Show all posts
                        </button>
                      </div>
                    ) : (
                      enrichedPosts.map(({ post, showDivider }) => (
                        <div key={post.id}>
                          {showDivider && (
                            <FeedSectionDivider
                              label="Free to read"
                              sublabel="Creators you don't follow yet"
                            />
                          )}
                          <FeedCard post={post} onClick={() => setSelectedPost(post)} />
                        </div>
                      ))
                    )}
                  </div>
                </div>
              ) : currentView === "profile" ? (
                <ProfilePage
                  onNavigate={(view) => navigateTo(view)}
                />
              ) : (
                <DiscoverGrid
                  items={DISCOVER_ITEMS}
                  onItemClick={handleDiscoverItemClick}
                />
              )}
            </div>
          </main>
        </div>
      </div>

      {/* Modals */}
      <SettingsModal isOpen={settingsOpen} onClose={() => setSettingsOpen(false)} />
      <LibraryModal
        isOpen={libraryOpen}
        onClose={() => setLibraryOpen(false)}
        onMatchVibe={handleMatchVibe}
      />

      {/* Gallery view modal */}
      {selectedPost && (
        <GalleryView
          post={selectedPost}
          onClose={() => setSelectedPost(null)}
          onNavigate={handleNavigate}
          hasPrev={selectedPostIndex > 0}
          hasNext={selectedPostIndex < filteredPosts.length - 1}
        />
      )}

      {/* Command palette */}
      {commandOpen && (
        <CommandPalette
          isOpen={commandOpen}
          onClose={() => setCommandOpen(false)}
          suggestions={[]}
        />
      )}
    </>
  );
}
